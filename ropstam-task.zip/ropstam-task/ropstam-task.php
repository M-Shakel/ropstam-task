<?php
/**
 * @package RopstamTask
 */
/*
Plugin Name: Ropstam Task
Plugin URI: https://shakeel.yellowpage.pk
Description: This is my first attempt to create the plugin.
Version: 1.0.0
Author: Muhammad Shakeel
Author URI: https://shakeel.yelleowpage.pk
License: GPLv2 or later
Text Domain: ropstam-task
 */
defined('ABSPATH') or die('Hey, You can\'t access this directly.');

function create_plugin_database_table()
{
    global $wpdb;

    $tablename = $wpdb->prefix.'websites';

    #Check to see if the table exists already, if not, then create it

    if($wpdb->get_var( "show tables like '$tablename'" ) != $tablename) 
    {

        $sql = "CREATE TABLE `". $tablename . "` ( ";
        $sql .= "  `ID`  int(11)   NOT NULL auto_increment, ";
        $sql .= "  `name`  varchar(250)   NOT NULL, ";
        $sql .= "  `website_url`  varchar(500)   NOT NULL, ";
        $sql .= "  `date_time`  datetime DEFAULT current_timestamp NOT NULL, ";
        $sql .= "  PRIMARY KEY `order_id` (`ID`) "; 
        $sql .= ") ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ; ";
        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        dbDelta($sql);
    }
}

 register_activation_hook( __FILE__, 'create_plugin_database_table' );

function web_html_form_code() {
   require_once('include/url-form.php');
   wcf_data_insert();
}

// this Code is for plugin data fetching
add_action( 'admin_menu', 'my_admin_menu' );
    
    function website_admin(){
// echo htmlspecialchars($data);

    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <?php
        global $wpdb;
        $websites = $wpdb->get_results("SELECT * FROM wp_websites ORDER BY ID DESC;");
        echo "<table class='widefat fixed'>";
        echo "<th>ID</th>";
        echo "<th>User Name</th>";
        echo "<th>Website URL</th>";
        echo "<th>Source Code</th>";
        echo "<th>Current Date / Time</th>";

        foreach($websites as $website){
            $sourceUrl = $website->website_url;
            $data = file_get_contents($sourceUrl);
            $html_sourcecode_get = htmlentities($data);
            echo "<tr>";
            echo "<td><input type='text' name='ID' value=".$website->ID." size='1' readonly></input></td>";
            echo "<td>".$website->name."</td>";
            echo "<td>".$website->website_url."</td>";
            echo "<td><textarea type='text' name='source' size='1' readonly >$html_sourcecode_get</textarea></td>";
            echo "<td>".$website->date_time."</td>";
            echo "</tr>";
        }
        echo "</table>";
        ?>
    </div>
    <?php
    }
    
    function my_admin_menu() {
        add_menu_page('Websites URLs', 'Websites', 'manage_options', 'websites-urls','web_html_form_code', 'dashicons-tag', 6  );
    }
    

    // this is submenu
     function my_admin_submenu() {
        add_submenu_page('edit.php?post_type=all-website', 'Websites URLs', 'Websites URLs' ,'manage_options', 'websites-urls', 'website_admin');
    }
    add_action('admin_menu', 'my_admin_submenu');

    function ropstam_task_cpt(){
        $args = array(
            'public' => true,
            'label' => 'All Websites',
            'menu_icon' => 'dashicons-admin-site-alt3',
        );
        register_post_type('all-website', $args );
    }
    add_action('init', 'ropstam_task_cpt');