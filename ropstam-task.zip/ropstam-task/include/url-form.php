<?php 
 /*
Template Name: Student
*/

 echo '<form action="' . esc_url( $_SERVER['REQUEST_URI'] ) . '" method="post">';
    echo '<p>';
    echo '<input  class="form-control" type="text" placeholder="Your Name " name="name" pattern="[a-zA-Z0-9 ]+" value="' . ( isset( $_POST["name"] ) ? esc_attr( $_POST["name"] ) : '' ) . '" size="40" />';
    echo '</p>';
    echo '<p>';
    echo '<input class="form-control" type="text" placeholder="Your website URL" name="website_url" value="' . ( isset( $_POST["website_url"] ) ? esc_attr( $_POST["website_url"] ) : '' ) . '" size="40" />';
    echo '</p>';
    echo '<p><input type="submit" name="wcf-submit" value="submit"  class="btn btn-default btn-block btn-primary mx-auto"></p>';
    echo '</form>';

function wcf_data_insert(){
        
    global $wpdb;

     $tablename = $wpdb->prefix.'websites';

     // $WCF_name = $_POST['name'];
     // $WCF_website_url = $_POST['website_url'];

    if (isset($_POST['wcf-submit'])) {
    	$data = array(
                'name' => $_POST['name'],
                'website_url' => $_POST['website_url'],
            );
       $result = $wpdb->insert( $tablename, $data, $format=NULL);
	    if (!empty($result)){
	        echo '<script>alert("Data Inserted succussfull")</script>';
	    }
    }
}

?>